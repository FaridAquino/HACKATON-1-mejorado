package com.example.hackaton_1_mejorada.Config.capa;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

@Configuration
@EnableScheduling
public class ScheduleConfig {
    // Aquí podrías agregar otras configuraciones relacionadas con tareas programadas
}
